$(document).ready(function(){
	if (document.title === "[承認者]　勤怠　実績確認") {
    $("div.globalnavi")
      .append("<input type='button' value='チェックを付ける' class='check-button'></input>")
      .bind("click", function(e) {
        $("[id^=BTNDCCOR]").each(function(){
          var tmp = $(this).attr("id").substr(8);
          tmp = tmp.substr(0, tmp.length - 1);
          $("#CHK" + tmp).prop("checked",true);
        });
      });
  }
});
